<?php
//get data from form  

$name = $_POST['Name'];
$email= $_POST['Email'];
$subject=$_POST['Subject'];
$message= $_POST['Message'];
$to = "saanvithatechnologies@gmail.com";
$subject = "Mail From SaanvithaTechnologies";
$txt ="Name = ". $name . "\r\n  Email = " . $email . "\r\n Subject =" . $message . "\r\n  Message = " . $message;
$headers = "From: noreply@sonuweddingdesigners.com" . "\r\n" .
"CC: somebodyelse@example.com";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:thankyou.html");
?>